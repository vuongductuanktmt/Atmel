#include "main.h"

void itoa(unsigned int n, unsigned char s[]);
void reverse(unsigned char s[],unsigned int n);
void buzzers(unsigned char x);
void getinput(unsigned int len,unsigned char x);
bit check(unsigned char *first, unsigned char *second, unsigned char len);
void lcd_custom_char(unsigned char add, unsigned char *k);
void store_code();
void newcode();
void changecode();
bit menu();