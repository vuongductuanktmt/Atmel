#include "lcd_16x2.h"
//Tao Xung
 void LCDWriteCmd(unsigned char c) //CT con ghi du lieu len LCD
 {
  LCD_PORT = c;
  RS = 0;
  RW = 0;
  EN = 1;
  delay_ms(5);
  EN = 0;

 }
 //==============================
void LCDWriteData(unsigned char c) //CT con doc du lieu tu LCD
 {
  LCD_PORT = c;
  RS = 1;
  RW = 0;
  EN = 1;
  delay_ms(1);
  EN = 0;

 }
 //=============================
void LCDcursorxy(unsigned char x, unsigned char y) {
  if ((x < 1 || x > 2) && (y < 1 || y > 16)) {
   x = 1;
   y = 1;
  }
  if (x == 1)
   LCDWriteCmd(0x7F + y);
  else
   LCDWriteCmd(0xBF + y);
 }
 //===============================
void LCD_init() // Khoi tao LCD
 {
  delay_ms(5);
  LCDWriteCmd(0x3c); // 8-bit data , 2 lines & 5x8 matrix 	
  delay_ms(1);
  LCDWriteCmd(0x0C); // Display On cursor blinking 	
  delay_ms(1);
  LCDWriteCmd(0x01); // clear LCD
  delay_ms(10);
  LCDWriteCmd(0x06); // increment cursor (shift cursor to right)
  delay_ms(1);
 }
 //================================
void LCD_Clear() {
  LCDWriteCmd(0x01);
  delay_ms(20);
 }
 //===============================
 //=============================
void LCD_putstr(unsigned char * s) {
 while ( * s) {
  LCDWriteData( * s);
  s++;
  delay_ms(5);
 }
}





